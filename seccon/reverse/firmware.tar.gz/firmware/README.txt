ctf4b networks SUPER SECURE device's firmware

*NOTE*

It is allowed to reverse engineer this firmware.
I hope you enjoy reversing this file!
